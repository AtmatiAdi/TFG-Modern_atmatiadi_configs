#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GBUFFERS_TERRAIN
#define WORLD_EUROPA
#define AD_ASTRA

#include "/program/gbuffers_terrain.glsl"
